README
------

This materials.zip contains two demo projects. The first is the top level
maven project that contains the demo code for most of the course. The second
is the spring-java-json-fundamentals project that contains the demo code for the Spring section of module 7.

In order to use the top level project you need to extract the citylots file, for
example by running `gunzip citylots.json.gz` on linux or by using your
favourite file extraction program on Windows or Mac OS. This should be extracted
into the same directory as the pom.xml resides.

After that you can import your pom.xml into your favourite IDE like any
other maven project
